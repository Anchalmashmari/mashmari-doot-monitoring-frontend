import React from 'react'
import Dashboardmain from '../components/DashboardMain'

const Dashmain = () => {
  return (
    <div>
      <Dashboardmain/>
    </div>
  )
}

export default Dashmain