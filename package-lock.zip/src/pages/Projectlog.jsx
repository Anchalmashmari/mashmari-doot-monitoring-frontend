import React from 'react'
import ProjectorLogsMain from '../components/ProjectorLogsMain'


const Projectlog = () => {
  return (
    <div>
   <ProjectorLogsMain/>     
    </div>
  )
}

export default Projectlog