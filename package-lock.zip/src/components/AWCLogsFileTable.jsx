import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FaFolder, FaChevronDown, FaChevronRight } from 'react-icons/fa';

const AWCLogsFileTable = () => {
  const [folders, setFolders] = useState([]);
  const [expandedFolder, setExpandedFolder] = useState(null);
  const [folderFiles, setFolderFiles] = useState({});

  useEffect(() => {
    const fetchFolders = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/v1/anganwadi/');
        setFolders(response.data.data.folders);
      } catch (error) {
        console.error('Error fetching folders:', error);
      }
    };

    fetchFolders();
  }, []);

  const toggleFolder = async (code, prefixPath) => {
    console.log("Clicked folder code:", code);
    console.log("Prefix path being passed:", prefixPath);

    if (expandedFolder === code) {
      setExpandedFolder(null);
    } else {
      setExpandedFolder(code);

      if (!folderFiles[code]) {
        try {
          const fullPrefix = `${prefixPath}/`;
          console.log("Final fullPrefix used in API:", fullPrefix);

          const response = await axios.get(`http://localhost:8000/api/v1/anganwadi?prefix=${fullPrefix}`);
          console.log("Full API URL being hit:", `http://localhost:8000/api/v1/anganwadi?prefix=${fullPrefix}`);

          setFolderFiles((prev) => ({
            ...prev,
            [code]: response.data.data.files || [],
          }));
        } catch (error) {
          console.error(`Error fetching files for ${code}:`, error);
        }
      }
    }
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white border">
        <thead>
          <tr className="bg-gray-200 text-left">
            <th className="py-2 px-4">Folder Code</th>
            <th className="py-2 px-4">Total Files</th>
            <th className="py-2 px-4">Last Modified</th>
          </tr>
        </thead>
        <tbody>
          {folders.map((folder) => (
            <React.Fragment key={folder.code}>
              <tr
                className="border-b cursor-pointer hover:bg-gray-50"
                onClick={() => toggleFolder(folder.code, folder.code)} // 👈 fixed here
              >
                <td className="py-2 px-4 flex items-center gap-2">
                  {expandedFolder === folder.code ? <FaChevronDown /> : <FaChevronRight />}
                  <FaFolder className="text-yellow-500" />
                  {folder.code}
                </td>
                <td className="py-2 px-4">{folder.fileCount}</td>
                <td className="py-2 px-4">{new Date(folder.lastModified).toLocaleString()}</td>
              </tr>

              {expandedFolder === folder.code && folderFiles[folder.code] && (
                <tr>
                  <td colSpan="3" className="py-2 px-4 bg-gray-50">
                    <ul className="list-disc ml-8">
                      {folderFiles[folder.code].length === 0 ? (
                        <li>No files found in this folder.</li>
                      ) : (
                        folderFiles[folder.code].map((file, index) => (
                          <li key={index}>{file}</li>
                        ))
                      )}
                    </ul>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AWCLogsFileTable;
