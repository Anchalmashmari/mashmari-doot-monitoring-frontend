
// import React from 'react';

// const AWCFilter = ({ filters, onChange }) => {
//   return (
//     <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
//       <select className="border p-2 rounded-md" value={filters.state} onChange={(e) => onChange('state', e.target.value)}>
//         <option value="">Select State</option>
//         <option>Uttar Pradesh</option>
//         <option>Madhya Pradesh</option>
//       </select>

//       <select className="border p-2 rounded-md" value={filters.district} onChange={(e) => onChange('district', e.target.value)}>
//         <option value="">Select District</option>
//         <option>Jhansi</option>
//         <option>Lalitpur</option>
//       </select>

//       <select className="border p-2 rounded-md" value={filters.cluster} onChange={(e) => onChange('cluster', e.target.value)}>
//         <option value="">Select Cluster</option>
//         <option>Cluster A</option>
//         <option>Cluster B</option>
//       </select>
//     </div>
//   );
// };

// export default AWCFilter;
// src/components/AWCFilter.jsx

import React from 'react';

const AWCFilter = ({ filters, onChange, codeOptions = [], statusOptions = [] }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      {/* Status Dropdown */}
      <select className="border p-2 rounded-md" value={filters.status} onChange={(e) => onChange('status', e.target.value)}>
        <option value="">Select Status</option>
        {statusOptions.map((status, idx) => (
          <option key={idx} value={status}>{status}</option>
        ))}
      </select>

      {/* Code Dropdown */}
      <select className="border p-2 rounded-md" value={filters.code} onChange={(e) => onChange('code', e.target.value)}>
        <option value="">Select Code</option>
        {codeOptions.map((code, idx) => (
          <option key={idx} value={code}>{code}</option>
        ))}
      </select>

      {/* Cluster Dropdown */}
      <select className="border p-2 rounded-md" value={filters.cluster} onChange={(e) => onChange('cluster', e.target.value)}>
        <option value="">Select Cluster</option>
        <option>Cluster A</option>
        <option>Cluster B</option>
      </select>
    </div>
  );
};


export default AWCFilter;
